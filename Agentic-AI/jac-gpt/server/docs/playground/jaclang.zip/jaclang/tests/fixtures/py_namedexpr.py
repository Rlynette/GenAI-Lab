from __future__ import annotations

# flake8: noqa

def walrus_example():
    if (x := 10) > 5:
        print(x)
