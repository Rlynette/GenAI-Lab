"""Test file for subclass issue."""

p = 5
g = 6


class A:
    """Dummy class to test the base class issue."""

    def start(self) -> int:
        """Return 0."""
        return 0
