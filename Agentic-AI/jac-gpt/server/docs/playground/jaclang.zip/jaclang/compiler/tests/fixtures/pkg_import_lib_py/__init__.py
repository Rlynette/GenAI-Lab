from jaclang import JacMachineInterface as _

from .tools import tool_func

glob_var_lib = "pkg_import_lib_py.glob_var_lib"
