"""
Test fixtures for the symtab link tests.

This is a package which have __init__.py file.
"""
