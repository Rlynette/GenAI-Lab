def set_mode(a, b):
    pass
