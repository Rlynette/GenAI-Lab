"""Plugin interface tests for Jac."""
